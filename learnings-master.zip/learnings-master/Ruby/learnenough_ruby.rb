#yield is nothing but a way to execute a custom block of code within our function 


def somefunc(arg1)

  print "hi"
  yield "dummy"

end

somefunc("sameer") do |text|

  puts "this is from the block #{text}"

end

#OUTPUT: 

# ruby main.rb
#hithis is from the block dummy
#

#observe that we have just called the function and additionally passed our custom block of code and that particular block of code will be executed whenever there is an yield statement in our main fucntion - if we give arguments to that yield keyword - then it will be passed back to the block. 


# if we dont pass a block in the function call then the fucntion will ignore the yield as we haven't passed any block ex: somefunc("hi there") o/p: hi 


================================ MAP ============================
def change 
  
 array1=["sameer shaik", "sameer", "shaik"]
  changedarray=[]
  array1.each do |element|
    changedarray << element.downcase.split.join("-")
  end
  puts changedarray
end


change

def changeusingmap
  array1=["sameer shaik", "sameer", "shaik"]
  array2=array1.map do |element|
    element.downcase.split.join("-")
  end
puts array2.inspect

end

# both the methods do the same thing - but the seconf one uses a simple map method to apply some login to all the elements in the input array 

=============================SELECT===============================

























